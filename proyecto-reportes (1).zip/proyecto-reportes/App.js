import React from 'react';
import { SafeAreaView } from 'react-native';

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <iframe
        srcDoc={`
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title>ReportaTJ</title>

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  background:#0f1117;
  color:white;
  font-family:Arial, Helvetica, sans-serif;
}

header{
  background:#161b22;
  padding:20px;
  display:flex;
  justify-content:space-between;
  align-items:center;
}

.logo{
  font-size:24px;
  font-weight:bold;
}

.logo span{
  color:#f5c518;
}

nav{
  display:flex;
  gap:10px;
}

button{
  cursor:pointer;
}

.nav-btn{
  background:none;
  border:none;
  color:white;
  padding:10px;
}

.nav-btn.active{
  color:#f5c518;
}

.view{
  display:none;
  padding:20px;
}

.view.active{
  display:block;
}

.card{
  background:#1c2128;
  border-radius:12px;
  padding:20px;
  margin-bottom:20px;
}

input, select, textarea{
  width:100%;
  margin-top:5px;
  margin-bottom:15px;
  padding:10px;
  border:none;
  border-radius:8px;
  background:#0d1117;
  color:white;
}

.btn-primary{
  width:100%;
  padding:12px;
  border:none;
  border-radius:8px;
  background:#f5c518;
  color:black;
  font-weight:bold;
}

.rep-item{
  background:#0d1117;
  border:1px solid #30363d;
  border-radius:10px;
  padding:15px;
  margin-bottom:10px;
}

.badge{
  padding:4px 10px;
  border-radius:20px;
  font-size:12px;
}

.b-nuevo{
  background:#1f6feb;
}

.b-proceso{
  background:#d29922;
}

.b-resuelto{
  background:#238636;
}

table{
  width:100%;
  border-collapse:collapse;
}

th, td{
  border-bottom:1px solid #30363d;
  padding:10px;
  text-align:left;
}

.btn-sm{
  padding:5px 10px;
  border:none;
  border-radius:6px;
  margin-right:5px;
}

.bsp{
  background:#d29922;
}

.bsr{
  background:#238636;
}

.bsd{
  background:#da3633;
  color:white;
}

#toast{
  position:fixed;
  bottom:20px;
  right:20px;
  background:#238636;
  color:white;
  padding:15px;
  border-radius:10px;
  display:none;
}
</style>
</head>

<body>

<header>
  <div class="logo">Reporta<span>TJ</span></div>

  <nav>
    <button class="nav-btn active" id="nb-home" onclick="ir('home')">
      Inicio
    </button>

    <button class="nav-btn" id="nb-ciudadano" onclick="ir('ciudadano')">
      Ciudadano
    </button>

    <button class="nav-btn" id="nb-admin" onclick="ir('admin')">
      Admin
    </button>
  </nav>
</header>

<!-- HOME -->
<div class="view active" id="home">

  <div
    style="
      min-height:85vh;
      display:flex;
      justify-content:center;
      align-items:center;
      padding:40px 20px;
      background:
      radial-gradient(circle at top left,#f5c51822,transparent 30%),
      radial-gradient(circle at bottom right,#1f6feb22,transparent 30%);
    "
  >

    <div
      style="
        max-width:900px;
        width:100%;
        text-align:center;
      "
    >

      <div
        style="
          display:inline-block;
          padding:8px 18px;
          border-radius:30px;
          background:#f5c51822;
          color:#f5c518;
          margin-bottom:25px;
          font-size:14px;
          font-weight:bold;
          letter-spacing:1px;
        "
      >
        SISTEMA CIUDADANO DE REPORTES
      </div>

      <h1
        style="
          font-size:60px;
          line-height:1.1;
          margin-bottom:20px;
          font-weight:800;
        "
      >
        Tu ciudad,<br>
        <span style="color:#f5c518;">
          tu voz
        </span>
      </h1>

      <p
        style="
          font-size:20px;
          color:#9ca3af;
          max-width:700px;
          margin:auto;
          line-height:1.7;
        "
      >
        Reporta baches, fugas de agua, basura y problemas
        de alumbrado en Tijuana de forma rápida y sencilla.
      </p>

      <div
        style="
          display:flex;
          gap:20px;
          justify-content:center;
          flex-wrap:wrap;
          margin-top:45px;
        "
      >

        <div
          onclick="ir('ciudadano')"
          style="
            background:#1c2128;
            border:1px solid #30363d;
            width:280px;
            padding:30px;
            border-radius:20px;
            cursor:pointer;
            transition:.3s;
          "
        >

          <div style="font-size:55px;margin-bottom:15px;">
            🏙
          </div>

          <h2 style="margin-bottom:10px;">
            Ciudadano
          </h2>

          <p style="color:#9ca3af;line-height:1.6;">
            Envía reportes urbanos y ayuda a mejorar la ciudad.
          </p>

        </div>

        <div
          onclick="ir('admin')"
          style="
            background:#1c2128;
            border:1px solid #30363d;
            width:280px;
            padding:30px;
            border-radius:20px;
            cursor:pointer;
            transition:.3s;
          "
        >

          <div style="font-size:55px;margin-bottom:15px;">
            ⚙️
          </div>

          <h2 style="margin-bottom:10px;">
            Administrador
          </h2>

          <p style="color:#9ca3af;line-height:1.6;">
            Gestiona reportes y actualiza estados municipales.
          </p>

        </div>

      </div>

      <div
        style="
          display:flex;
          justify-content:center;
          gap:50px;
          flex-wrap:wrap;
          margin-top:55px;
        "
      >

        <div>
          <h2 style="color:#f5c518;font-size:35px;">
            24/7
          </h2>
          <p style="color:#9ca3af;">
            Disponible
          </p>
        </div>

        <div>
          <h2 style="color:#1f6feb;font-size:35px;">
            +100
          </h2>
          <p style="color:#9ca3af;">
            Reportes
          </p>
        </div>

        <div>
          <h2 style="color:#238636;font-size:35px;">
            100%
          </h2>
          <p style="color:#9ca3af;">
            Digital
          </p>
        </div>

      </div>

    </div>

  </div>

</div>

<!-- CIUDADANO -->
<div class="view" id="ciudadano">

  <div class="card">

    <h2>Nuevo Reporte</h2>

    <br>

    <label>Tipo</label>

    <select id="f-tipo">
      <option value="">Selecciona</option>
      <option value="Bache">Bache</option>
      <option value="Fuga de agua">Fuga de agua</option>
      <option value="Alumbrado">Alumbrado</option>
      <option value="Basura">Basura</option>
    </select>

    <label>Colonia</label>

    <input
      type="text"
      id="f-colonia"
      placeholder="Ejemplo: Zona Río"
    />

    <label>Descripción</label>

    <textarea
      id="f-desc"
      placeholder="Describe el problema"
    ></textarea>

    <button class="btn-primary" onclick="crearReporte()">
      Enviar Reporte
    </button>

  </div>

  <div class="card">

    <h2>Mis Reportes</h2>

    <br>

    <div id="reports-list">
      No hay reportes.
    </div>

  </div>

</div>

<!-- ADMIN -->
<div class="view" id="admin">

  <div class="card">

    <h2>Panel Administrativo</h2>

    <br>

    <table>

      <thead>
        <tr>
          <th>ID</th>
          <th>Tipo</th>
          <th>Colonia</th>
          <th>Descripción</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>

      <tbody id="a-tbody"></tbody>

    </table>

  </div>

</div>

<div id="toast"></div>

<script>

const KEY = 'reportesTJ';

function getR(){
  return JSON.parse(localStorage.getItem(KEY) || '[]');
}

function saveR(arr){
  localStorage.setItem(KEY, JSON.stringify(arr));
}

if(getR().length === 0){

  saveR([
    {
      id: Date.now(),
      tipo:'Bache',
      colonia:'Zona Río',
      desc:'Bache peligroso',
      estado:'Nuevo'
    }
  ]);

}

const ICONS = {
  'Bache':'🕳',
  'Fuga de agua':'💧',
  'Alumbrado':'💡',
  'Basura':'🗑'
};

const BCLS = {
  'Nuevo':'b-nuevo',
  'En proceso':'b-proceso',
  'Resuelto':'b-resuelto'
};

function toast(msg){

  const t = document.getElementById('toast');

  t.innerText = msg;

  t.style.display = 'block';

  setTimeout(() => {
    t.style.display = 'none';
  }, 3000);
}

function ir(v){

  const views = ['home','ciudadano','admin'];

  views.forEach(id => {

    document
      .getElementById(id)
      .classList.remove('active');

    document
      .getElementById('nb-' + id)
      .classList.remove('active');

  });

  document
    .getElementById(v)
    .classList.add('active');

  document
    .getElementById('nb-' + v)
    .classList.add('active');

  if(v === 'ciudadano'){
    renderLista();
  }

  if(v === 'admin'){
    renderTabla();
  }
}

function crearReporte(){

  const tipo =
    document.getElementById('f-tipo').value;

  const colonia =
    document.getElementById('f-colonia').value;

  const desc =
    document.getElementById('f-desc').value;

  if(!tipo || !colonia || !desc){

    toast('Completa todos los campos');

    return;
  }

  const nuevo = {
    id: Date.now(),
    tipo,
    colonia,
    desc,
    estado:'Nuevo'
  };

  const arr = getR();

  arr.unshift(nuevo);

  saveR(arr);

  document.getElementById('f-tipo').value = '';
  document.getElementById('f-colonia').value = '';
  document.getElementById('f-desc').value = '';

  renderLista();

  toast('Reporte enviado');
}

function renderLista(){

  const list =
    document.getElementById('reports-list');

  const arr = getR();

  if(arr.length === 0){

    list.innerHTML = 'No hay reportes';

    return;
  }

  list.innerHTML = arr.map(r => \`
    <div class="rep-item">

      <h3>
        \${ICONS[r.tipo]} \${r.tipo}
      </h3>

      <br>

      <p>
        <strong>Colonia:</strong>
        \${r.colonia}
      </p>

      <p>
        <strong>Descripción:</strong>
        \${r.desc}
      </p>

      <br>

      <span class="badge \${BCLS[r.estado]}">
        \${r.estado}
      </span>

    </div>
  \`).join('');
}

function renderTabla(){

  const tbody =
    document.getElementById('a-tbody');

  const arr = getR();

  tbody.innerHTML = arr.map(r => \`

    <tr>

      <td>\${r.id}</td>

      <td>
        \${ICONS[r.tipo]} \${r.tipo}
      </td>

      <td>
        \${r.colonia}
      </td>

      <td>
        \${r.desc}
      </td>

      <td>
        <span class="badge \${BCLS[r.estado]}">
          \${r.estado}
        </span>
      </td>

      <td>

        <button
          class="btn-sm bsp"
          onclick="cambiarEstado(\${r.id}, 'En proceso')"
        >
          Proceso
        </button>

        <button
          class="btn-sm bsr"
          onclick="cambiarEstado(\${r.id}, 'Resuelto')"
        >
          Resuelto
        </button>

        <button
          class="btn-sm bsd"
          onclick="eliminar(\${r.id})"
        >
          Eliminar
        </button>

      </td>

    </tr>

  \`).join('');
}

function cambiarEstado(id, estado){

  const arr = getR();

  const index =
    arr.findIndex(r => r.id === id);

  if(index === -1){
    return;
  }

  arr[index].estado = estado;

  saveR(arr);

  renderTabla();

  renderLista();

  toast('Estado actualizado');
}

function eliminar(id){

  const arr =
    getR().filter(r => r.id !== id);

  saveR(arr);

  renderTabla();

  renderLista();

  toast('Reporte eliminado');
}

renderLista();

</script>

</body>
</html>
        `}
        style={{
          width: '100%',
          height: '100%',
          border: 'none'
        }}
      />
    </SafeAreaView>
  );
}